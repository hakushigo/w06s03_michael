package id.ac.del.pam.w06s03

import androidx.compose.ui.graphics.vector.ImageVector

data class BottomBarItem(val title:String, val icon:ImageVector)
